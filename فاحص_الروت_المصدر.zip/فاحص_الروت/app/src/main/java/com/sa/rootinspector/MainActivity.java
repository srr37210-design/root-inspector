package com.sa.rootinspector;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Typeface;
import android.graphics.Color;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;

public class MainActivity extends Activity {
    private LinearLayout content;
    private String report = "";
    private static final int PICK_FIRMWARE = 701;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(22), dp(18), dp(24));
        content.setBackgroundColor(Color.rgb(246,248,247));
        scroll.addView(content);
        setContentView(scroll);
        header("فاحص الروت", "تقرير الجهاز وتحليل ملفات Firmware قبل الروت");
        addButton("فحص الجهاز الآن", v -> runDeviceScan());
        addButton("اختيار ملف Firmware للتحليل", v -> pickFirmware());
        addButton("نسخ التقرير", v -> copyReport());
        addButton("مشاركة التقرير كنص", v -> shareReport());
        note("ملاحظة أمان: التطبيق لا يفتح البوت لودر ولا يفلش أي شيء. لا يمكن لتطبيق عادي قراءة كل الأقسام المحمية، وقد تكون بعض النتائج غير متاحة.");
        runDeviceScan();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT); t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG); t.setPadding(0, dp(5), 0, dp(5));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void header(String title, String subtitle) {
        TextView h = text(title, 26, true, Color.WHITE); h.setPadding(dp(16),dp(18),dp(16),dp(3)); h.setBackgroundColor(Color.rgb(18,63,56)); content.addView(h);
        TextView s = text(subtitle, 14, false, Color.WHITE); s.setPadding(dp(16),0,dp(16),dp(18)); s.setBackgroundColor(Color.rgb(18,63,56)); content.addView(s);
    }
    private void section(String title, String body) {
        TextView h = text(title, 18, true, Color.rgb(18,63,56)); h.setPadding(0,dp(18),0,dp(5)); content.addView(h);
        TextView b = text(body, 14, false, Color.rgb(35,45,42)); b.setBackgroundColor(Color.WHITE); b.setPadding(dp(13),dp(12),dp(13),dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin = dp(7); content.addView(b,lp);
    }
    private void note(String s) { TextView t=text(s,12,false,Color.rgb(92,72,18)); t.setBackgroundColor(Color.rgb(255,247,220)); t.setPadding(dp(12),dp(12),dp(12),dp(12)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(12); content.addView(t,p); }
    private void addButton(String label, View.OnClickListener click) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(7); content.addView(b,p);
    }
    private String prop(String key) {
        try { Process p = Runtime.getRuntime().exec(new String[]{"/system/bin/getprop", key}); ByteArrayOutputStream out = new ByteArrayOutputStream(); InputStream in=p.getInputStream(); byte[] buf=new byte[512]; int n; while((n=in.read(buf))>0) out.write(buf,0,n); p.waitFor(); return out.toString("UTF-8").trim(); } catch(Exception e) { return ""; }
    }
    private String val(String s) { return (s==null || s.trim().isEmpty()) ? "غير متاح من صلاحيات التطبيق" : s.trim(); }
    private void runDeviceScan() {
        StringBuilder r = new StringBuilder();
        r.append("تقرير فاحص الروت\n");
        String[][] rows = {
            {"الشركة المصنعة", Build.MANUFACTURER}, {"الشركة", Build.BRAND}, {"الموديل", Build.MODEL}, {"اسم الجهاز", Build.DEVICE}, {"اسم المنتج", Build.PRODUCT},
            {"رقم الطراز", Build.HARDWARE}, {"إصدار Android", Build.VERSION.RELEASE}, {"مستوى API", String.valueOf(Build.VERSION.SDK_INT)},
            {"رقم البناء", Build.DISPLAY}, {"Build ID", Build.ID}, {"Fingerprint", Build.FINGERPRINT}, {"النواة", System.getProperty("os.version")},
            {"تصحيح الأمان", Build.VERSION.SECURITY_PATCH}, {"المعمارية", join(Build.SUPPORTED_ABIS)},
            {"النطاق الأساسي", prop("gsm.version.baseband")}, {"نوع البناء", prop("ro.build.type")}, {"مسار البناء", prop("ro.build.version.incremental")},
            {"حالة Verified Boot", prop("ro.boot.verifiedbootstate")}, {"حالة AVB", prop("ro.boot.vbmeta.device_state")},
            {"حالة الإقلاع", prop("ro.boot.bootloader")}, {"وضع الإقلاع", prop("ro.bootmode")}, {"فتحة A/B", prop("ro.boot.slot_suffix")},
            {"مؤشر Magisk", detectMagisk()}, {"مؤشرات root", detectRoot()}
        };
        for (String[] row : rows) { String v=val(row[1]); r.append(row[0]).append(": ").append(v).append("\n"); }
        r.append("\nملاحظة: قيمة bootloader قد تكون إصدار محمّل الإقلاع وليست دليلاً قاطعاً على أنه مفتوح.\n");
        report = r.toString();
        section("بيانات الجهاز والنظام", report);
        section("ما الذي تعنيه النتائج؟", "استخدم رقم الطراز وFingerprint ورقم البناء لاختيار Firmware مطابق تماماً. حالة Verified Boot مثل green/orange قد تساعد لكنها لا تثبت وحدها حالة البوت لودر. لا تفلش boot.img أو init_boot.img من إصدار مختلف.");
    }
    private String join(String[] a) { if(a==null) return ""; StringBuilder b=new StringBuilder(); for(String s:a){if(b.length()>0)b.append(", ");b.append(s);}return b.toString(); }
    private String detectMagisk() { java.io.File[] paths={new java.io.File("/sbin/.magisk"),new java.io.File("/data/adb/magisk"),new java.io.File("/debug_ramdisk/.magisk")}; for(java.io.File f:paths) if(f.exists()) return "عُثر على مؤشر محتمل: "+f.getPath(); return "لم يُعثر على مؤشر واضح (لا ينفي وجوده)"; }
    private String detectRoot() { String[] paths={"/system/bin/su","/system/xbin/su","/sbin/su","/su/bin/su"}; for(String p:paths) if(new java.io.File(p).exists()) return "عُثر على ملف محتمل: "+p; return "لم يُعثر على su في المسارات الشائعة (لا ينفي الروت)"; }
    private void pickFirmware() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        try { startActivityForResult(i,PICK_FIRMWARE); } catch(Exception e) { Toast.makeText(this,"تعذر فتح منتقي الملفات",Toast.LENGTH_LONG).show(); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_FIRMWARE && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData(); String name=uri.getLastPathSegment();
            String result;
            try { result=analyzeFile(uri,name); } catch(Exception e) { result="تعذر تحليل الملف: "+e.getMessage()+"\nقد يكون تنسيق الملف غير مدعوم أو الملف تالفاً."; }
            report += "\n\nتحليل Firmware\n"+result;
            section("تحليل ملف Firmware",result);
        }
    }
    private String analyzeFile(Uri uri, String name) throws Exception {
        String lower=(name==null?"":name).toLowerCase(Locale.ROOT);
        StringBuilder out=new StringBuilder(); out.append("اسم/معرّف الملف: ").append(name).append("\n");
        out.append("تحليل مبدئي فقط؛ لا يتم تعديل الملف أو تفليشه.\n\n");
        InputStream raw=getContentResolver().openInputStream(uri); if(raw==null) return "تعذر فتح الملف.";
        if(lower.endsWith(".zip")) {
            ZipInputStream zin=new ZipInputStream(raw); ZipEntry e; int count=0; List<String> hits=new ArrayList<>();
            while((e=zin.getNextEntry())!=null && count<20000) { count++; String n=e.getName(); if(isInteresting(n)) hits.add(n); }
            zin.close(); out.append("نوع الملف: ZIP\nعدد الإدخالات التي تمت معاينتها: ").append(count).append("\n");
            if(hits.isEmpty()) out.append("لم تظهر أسماء أقسام معروفة ضمن الإدخالات التي تمت قراءتها. إذا كان هذا ملف Firmware من سامسونج فقد يحتوي ZIP على ملفات AP/BL/CP/CSC.");
            else { out.append("الملفات المهمة المكتشفة:\n"); for(String h:hits) out.append("• ").append(h).append("\n"); }
            appendAdvice(out,hits);
        } else {
            byte[] head=new byte[512]; int n=raw.read(head); raw.close();
            boolean tar=n>=262 && head[257]=='u' && head[258]=='s' && head[259]=='t' && head[260]=='a' && head[261]=='r';
            out.append("نوع الملف: ").append(tar?"يبدو أنه TAR أو TAR.MD5":"غير معروف من الترويسة الأولى").append("\n");
            out.append("حجم الترويسة المقروءة: ").append(Math.max(n,0)).append(" بايت\n");
            if(tar) out.append("هذا إصدار أولي: لم يتم سرد كل محتويات TAR.MD5. ارفع الملف أو استخدم ملف AP داخل Firmware ZIP لفحص الأسماء بشكل أوسع.\n");
            else out.append("جرّب اختيار ملف ZIP الخارجي للـ Firmware، أو ملف AP/BL/CP/CSC المناسب.\n");
            out.append("لا يمكن استنتاج ملف الإقلاع الصحيح من اسم الملف وحده.");
        }
        return out.toString();
    }
    private boolean isInteresting(String s) { String x=s.toLowerCase(Locale.ROOT); return x.contains("ap_")||x.contains("bl_")||x.contains("cp_")||x.contains("csc_")||x.contains("boot.img")||x.contains("init_boot")||x.contains("vendor_boot")||x.contains("vbmeta")||x.endsWith(".tar.md5")||x.endsWith(".img.lz4")||x.endsWith(".lz4"); }
    private void appendAdvice(StringBuilder out,List<String> hits) {
        boolean ap=false, boot=false, init=false, vb=false;
        for(String h:hits){String x=h.toLowerCase(Locale.ROOT); if(x.contains("ap_")||x.contains("boot.img"))ap=true; if(x.contains("boot.img"))boot=true; if(x.contains("init_boot"))init=true; if(x.contains("vbmeta"))vb=true;}
        out.append("\n\nملخص أولي:\n");
        out.append("وجود AP/ملفات إقلاع: ").append(ap?"نعم، حسب أسماء الملفات":"لم يتم تأكيده").append("\n");
        out.append("boot.img: ").append(boot?"ظهر بالاسم":"لم يظهر بالاسم").append("\n");
        out.append("init_boot.img: ").append(init?"ظهر بالاسم":"لم يظهر بالاسم").append("\n");
        out.append("vbmeta: ").append(vb?"ظهر بالاسم":"لم يظهر بالاسم").append("\n");
        out.append("هذا فحص للأسماء فقط؛ بعض ملفات سامسونج مضغوطة بصيغة LZ4 داخل TAR.MD5، وقد لا يظهر اسم الصورة مباشرة عند فحص ZIP الخارجي.");
    }
    private void copyReport() { if(report.isEmpty()) { Toast.makeText(this,"لا يوجد تقرير",Toast.LENGTH_SHORT).show(); return; } ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("تقرير فاحص الروت",report)); Toast.makeText(this,"تم نسخ التقرير",Toast.LENGTH_SHORT).show(); }
    private void shareReport() { if(report.isEmpty()) return; Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,"تقرير فاحص الروت"); i.putExtra(Intent.EXTRA_TEXT,report); startActivity(Intent.createChooser(i,"مشاركة التقرير")); }
}
